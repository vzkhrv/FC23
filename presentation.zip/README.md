# Название доклада

Слайды для доклада на конференцию [FrontendConf 2023](https://frontendconf.ru/moscow/2023) в Москве

## Аннотация

...

## Целевая аудитория

...

## Благодарности

Сделано в [Shower](https://github.com/shower/shower)
